/* Enteros entre 1 y 9 */
#include <stdio.h>
int main()
{   int i;

    for (i=1; i<10; i=i+1)
        printf("i = %d \n", i);

    return 0;
}