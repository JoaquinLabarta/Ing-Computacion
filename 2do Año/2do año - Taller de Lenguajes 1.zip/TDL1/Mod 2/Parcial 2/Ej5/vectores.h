#ifndef VECTORES_H_INCLUDED
#define VECTORES_H_INCLUDED
float suma(float [],int);
float promedio(float [],int);
#endif