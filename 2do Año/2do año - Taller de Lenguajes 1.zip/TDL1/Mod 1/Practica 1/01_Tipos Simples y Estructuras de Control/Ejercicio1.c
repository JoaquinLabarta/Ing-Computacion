*/ Este c�digo tiene errores /*
#include <stdio.h>
int main()
{  
   printf("Ingrese un n�mero entero : \n");
   scanf("d", nro);

   printf("El valor ingresado es %d", &nro);

   return 0;
}
