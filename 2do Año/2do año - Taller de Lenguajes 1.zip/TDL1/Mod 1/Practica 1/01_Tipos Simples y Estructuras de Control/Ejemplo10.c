/* do - while */
#include <stdio.h>
int main()
{   int cant = 1;

    do
        printf("%d  ", cant);
    while (++cant <= 10);

    return 0;
}