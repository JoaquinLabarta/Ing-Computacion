/* lee dos enteros y los suma */
#include <stdio.h>
int main()
{  int nro1, nro2, suma;

   printf("Ingrese el 1er.nro : ");
   scanf("%d", &nro1);

   printf("Ingrese el 2do.nro : ");
   scanf("%d", &nro2);

   suma = nro1 + nro2;
   printf("La suma es %d \n", suma);

   return 0;
}
