/* Mi primer programa C */
#include <stdio.h>
int main()
{
    printf("Bienvenido a \n");
    printf("Taller de Lenguajes 1! \n");

    return 0;
}
