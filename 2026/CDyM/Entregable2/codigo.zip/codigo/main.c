#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>
#include "lcd.h"

//Constantes
#define TRUE 1
#define FALSE 0
#define KEY_NONE 0
#define MAX_TIEMPO_SEGUNDOS 5999U
#define LCD_COLUMNS 16

//Pines de LEDs indicadores
#define LED_ALARMA_PIN PC5
#define LED_INTERIOR_PIN PC4
#define LED_MAGNETRON_PIN PB5

//Pines del teclado matricial 4x4
#define KEYPAD_ROW0_PIN PB4
#define KEYPAD_ROW1_PIN PB3
#define KEYPAD_ROW2_PIN PB0
#define KEYPAD_ROW3_PIN PD7
#define KEYPAD_COL0_PIN PD3
#define KEYPAD_COL1_PIN PD5
#define KEYPAD_COL2_PIN PD4
#define KEYPAD_COL3_PIN PD2

//Mensajes temporales del LCD.
#define MSG_NONE 0
#define MSG_PUERTA_ABIERTA 1
#define MSG_TIEMPO_CERO 2
#define MSG_INVALIDO 3

//Estados de la maquina de estados del microondas
typedef enum
{
    MW_IDLE = 0,
    MW_COCINANDO,
    MW_PAUSADO,
    MW_TERMINADO
} micro_estados_t;

//Flags compartidos con la ISR del Timer0
static volatile uint8_t Flag_Keypad_10ms = 0;
static volatile uint8_t Flag_MEF_100ms = 0;
static volatile uint8_t Flag_Blink_500ms = 0;
static volatile uint8_t Flag_OneSecond = 0;

//Variables privadas del teclado
static char Keypad_event = KEY_NONE;
static char Keypad_candidate = KEY_NONE;
static uint8_t Keypad_stable_count = 0;
static uint8_t Keypad_pressed_lock = FALSE;

//Variables privadas de la aplicacion
static micro_estados_t Estado_sistema = MW_IDLE;
static uint16_t Tiempo_coccion_segundos = 0;
static uint8_t Tiempo_digitos[4] = {0, 0, 0, 0};
static uint8_t Puerta_abierta = FALSE;
static uint8_t Pantalla_sucia = TRUE;
static uint8_t Parpadeo = TRUE;
static uint8_t Finalizado_segundos_transcurridos = 0;
static uint16_t Contador_llamados_estado = 0;
static uint8_t Message_code = MSG_NONE;
static uint8_t Message_ticks_100ms = 0;

//Prototipos privados
static void MCU_Init(void);
static void TIMER0_Init_1ms(void);
static void KEYPAD_Init(void);
static void KEYPAD_Update(void);
static char KEYPAD_GetKeyEvent(void);
static char KEYPAD_ScanRaw(void);
static void KEYPAD_SetAllRowsHigh(void);
static void KEYPAD_SetRowLow(uint8_t row);
static uint8_t KEYPAD_IsColumnLow(uint8_t column);
static void KEYPAD_Settle(void);
static void MICROONDAS_Init(void);
static void MICROONDAS_Update(void);
static void MICROONDAS_ProcessKey(char key);
static void MICROONDAS_OneSecondTask(void);
static void MICROONDAS_Parpadear(void);
static void MICROONDAS_CambiarEstado(micro_estados_t nuevo_estado);
static void MICROONDAS_LimpiarTiempo(void);
static void MICROONDAS_InputDigit(uint8_t digit);
static uint16_t MICROONDAS_DigitsToSeconds(void);
static void MICROONDAS_LoadDigitsFromSeconds(uint16_t total_seconds);
static void MICROONDAS_30Seconds(void);
static void MICROONDAS_EmpezarCoccion(void);
static void MICROONDAS_ActualizarLeds(void);
static void MICROONDAS_ActualizarDisplay(void);
static void MICROONDAS_Printear(uint8_t code);

//ISR del Timer0. Ocurre cada 1 ms y solo levanta flags de tareas periodicas
ISR(TIMER0_COMPA_vect)
{
    static uint8_t count_10ms = 0;
    static uint8_t count_100ms = 0;
    static uint16_t count_500ms = 0;
    static uint16_t count_1000ms = 0;

    count_10ms++;
    if (count_10ms >= 10)
    {
        count_10ms = 0;
        Flag_Keypad_10ms = 1;
    }

    count_100ms++;
    if (count_100ms >= 100)
    {
        count_100ms = 0;
        Flag_MEF_100ms = 1;
    }

    count_500ms++;
    if (count_500ms >= 500)
    {
        count_500ms = 0;
        Flag_Blink_500ms = 1;
    }

    count_1000ms++;
    if (count_1000ms >= 1000)
    {
        count_1000ms = 0;
        Flag_OneSecond = 1;
    }
}

//Main principal
int main(void)
{
    cli();

    MCU_Init();
    LCD_Init();
    KEYPAD_Init();
    MICROONDAS_Init();
    TIMER0_Init_1ms();

    sei();

    while (1)
    {
        if (Flag_Keypad_10ms != 0)
        {
            Flag_Keypad_10ms = 0;
            KEYPAD_Update();
        }

        if (Flag_OneSecond != 0)
        {
            Flag_OneSecond = 0;
            MICROONDAS_OneSecondTask();
        }

        if (Flag_Blink_500ms != 0)
        {
            Flag_Blink_500ms = 0;
            MICROONDAS_Parpadear();
        }

        if (Flag_MEF_100ms != 0)
        {
            Flag_MEF_100ms = 0;
            MICROONDAS_Update();
        }
    }

    return 0;
}

//Inicializa puertos en un estado conocido
static void MCU_Init(void)
{
    DDRB = 0x00;
    DDRC = 0x00;
    DDRD = 0x00;

    PORTB = 0x00;
    PORTC = 0x00;
    PORTD = 0x00;

    DDRB |= (1 << LED_MAGNETRON_PIN);
    DDRC |= (1 << LED_ALARMA_PIN) | (1 << LED_INTERIOR_PIN);

    PORTB &= ~(1 << LED_MAGNETRON_PIN);
    PORTC &= ~((1 << LED_ALARMA_PIN) | (1 << LED_INTERIOR_PIN));
}

//Configura Timer0 en modo CTC con interrupcion cada 1 ms. Calculo para F_CPU = 16 MHz: 16 MHz / 64 = 250 kHz; periodo = 4 us; OCR0A = 249 da 250 cuentas.
static void TIMER0_Init_1ms(void)
{
    TCCR0A = 0x00;
    TCCR0B = 0x00;
    TCNT0 = 0;
    OCR0A = 249;
    TCCR0A |= (1 << WGM01);
    TIMSK0 |= (1 << OCIE0A);
    TCCR0B |= (1 << CS01) | (1 << CS00);
}

//Inicializa el teclado: filas como salidas y columnas como entradas con pull-up
static void KEYPAD_Init(void)
{
    DDRB |= (1 << KEYPAD_ROW0_PIN) | (1 << KEYPAD_ROW1_PIN) | (1 << KEYPAD_ROW2_PIN);
    DDRD |= (1 << KEYPAD_ROW3_PIN);

    DDRD &= ~((1 << KEYPAD_COL0_PIN) | (1 << KEYPAD_COL1_PIN) |
              (1 << KEYPAD_COL2_PIN) | (1 << KEYPAD_COL3_PIN));

    PORTD |= (1 << KEYPAD_COL0_PIN) | (1 << KEYPAD_COL1_PIN) |
             (1 << KEYPAD_COL2_PIN) | (1 << KEYPAD_COL3_PIN);

    KEYPAD_SetAllRowsHigh();
}

//Actualiza el teclado cada 10 ms y aplica antirrebote
static void KEYPAD_Update(void)
{
    char raw_key = KEYPAD_ScanRaw();

    if (raw_key == KEY_NONE)
    {
        Keypad_pressed_lock = FALSE;
        Keypad_candidate = KEY_NONE;
        Keypad_stable_count = 0;
    }
    else
    {
        if (raw_key == Keypad_candidate)
        {
            if (Keypad_stable_count < 10)
            {
                Keypad_stable_count++;
            }

            if ((Keypad_stable_count >= 3) && (Keypad_pressed_lock == FALSE))
            {
                if (Keypad_event == KEY_NONE)
                {
                    Keypad_event = raw_key;
                }

                Keypad_pressed_lock = TRUE;
            }
        }
        else
        {
            Keypad_candidate = raw_key;
            Keypad_stable_count = 1;
        }
    }
}

//Devuelve una tecla validada y limpia el evento
static char KEYPAD_GetKeyEvent(void)
{
    char key=Keypad_event;
    Keypad_event = KEY_NONE;
    return key;
}

//Escanea la matriz 4x4 sin antirrebote.
static char KEYPAD_ScanRaw(void)
{
    static const char keymap[4][4] =
    {
        {'1', '2', '3', 'A'},
        {'4', '5', '6', 'B'},
        {'7', '8', '9', 'C'},
        {'*', '0', '#', 'D'}
    };

    uint8_t row;
    uint8_t column;
    char found_key=found_key = KEY_NONE;

    for (row = 0; row < 4; row++)
    {
        KEYPAD_SetAllRowsHigh();
        KEYPAD_SetRowLow(row);
        KEYPAD_Settle();

        for (column = 0; column < 4; column++)
        {
            if (KEYPAD_IsColumnLow(column) != FALSE)
            {
                found_key = keymap[row][column];
                break;
            }
        }

        if (found_key != KEY_NONE)
        {
            break;
        }
    }

    KEYPAD_SetAllRowsHigh();
    return found_key;
}

//Coloca todas las filas del teclado en alto
static void KEYPAD_SetAllRowsHigh(void)
{
    PORTB |= (1 << KEYPAD_ROW0_PIN) | (1 << KEYPAD_ROW1_PIN) | (1 << KEYPAD_ROW2_PIN);
    PORTD |= (1 << KEYPAD_ROW3_PIN);
}

//Coloca una fila especifica en bajo para escanear el teclado
static void KEYPAD_SetRowLow(uint8_t row)
{
    switch (row)
    {
        case 0:
            PORTB &= ~(1 << KEYPAD_ROW0_PIN);
            break;

        case 1:
            PORTB &= ~(1 << KEYPAD_ROW1_PIN);
            break;

        case 2:
            PORTB &= ~(1 << KEYPAD_ROW2_PIN);
            break;

        case 3:
            PORTD &= ~(1 << KEYPAD_ROW3_PIN);
            break;

        default:
            break;
    }
}

//Lee una columna y devuelve TRUE si esta en bajo
static uint8_t KEYPAD_IsColumnLow(uint8_t column)
{
    switch (column)
    {
        case 0:
            return ((PIND & (1 << KEYPAD_COL0_PIN)) == 0) ? TRUE : FALSE;

        case 1:
            return ((PIND & (1 << KEYPAD_COL1_PIN)) == 0) ? TRUE : FALSE;

        case 2:
            return ((PIND & (1 << KEYPAD_COL2_PIN)) == 0) ? TRUE : FALSE;

        case 3:
            return ((PIND & (1 << KEYPAD_COL3_PIN)) == 0) ? TRUE : FALSE;

        default:
            return FALSE;
    }
}

//Pequeña espera para que se estabilicen los niveles de la matriz
static void KEYPAD_Settle(void)
{
    volatile uint8_t i;
    for (i = 0; i < 30; i++)
    {
    }
}

//Inicializa la aplicacion del microondas
static void MICROONDAS_Init(void)
{
    Estado_sistema = MW_IDLE;
    Puerta_abierta = FALSE;
    Parpadeo = TRUE;
    Message_code = MSG_NONE;
    Message_ticks_100ms = 0;
    Contador_llamados_estado = 0;
    MICROONDAS_LimpiarTiempo();
    MICROONDAS_ActualizarLeds();
    MICROONDAS_ActualizarDisplay();
    Pantalla_sucia = FALSE;
}

//Actualiza la maquina de estados cada 100 ms
static void MICROONDAS_Update(void)
{
    char key;
    Contador_llamados_estado++;
    if (Message_ticks_100ms != 0)
    {
        Message_ticks_100ms--;
        if (Message_ticks_100ms == 0)
        {
            Message_code = MSG_NONE;
            Pantalla_sucia = TRUE;
        }
    }

    key = KEYPAD_GetKeyEvent();
    if (key != KEY_NONE)
    {
        MICROONDAS_ProcessKey(key);
    }

    MICROONDAS_ActualizarLeds();

    if (Pantalla_sucia != FALSE)
    {
        MICROONDAS_ActualizarDisplay();
        Pantalla_sucia = FALSE;
    }
}

//Procesa las teclas como eventos de entrada de la MEF
static void MICROONDAS_ProcessKey(char key)
{
    if ((key >= '0') && (key <= '9'))
    {
        if (Estado_sistema == MW_IDLE)
        {
            MICROONDAS_InputDigit((uint8_t)(key - '0'));
        }

        return;
    }

    switch (key)
    {
        case 'A':
            if ((Estado_sistema == MW_IDLE) || (Estado_sistema == MW_PAUSADO))
            {
                MICROONDAS_EmpezarCoccion();
            }
            break;

        case 'B':
            if (Estado_sistema == MW_IDLE)
            {
                MICROONDAS_LimpiarTiempo();
            }
            else if (Estado_sistema == MW_COCINANDO)
            {
                MICROONDAS_CambiarEstado(MW_PAUSADO);
            }
            else if (Estado_sistema == MW_PAUSADO)
            {
                MICROONDAS_LimpiarTiempo();
                MICROONDAS_CambiarEstado(MW_IDLE);
            }
            else if (Estado_sistema == MW_TERMINADO)
            {
                MICROONDAS_LimpiarTiempo();
                MICROONDAS_CambiarEstado(MW_IDLE);
            }
            break;

        case 'C':
            if (Estado_sistema == MW_TERMINADO)
            {
                MICROONDAS_LimpiarTiempo();
                MICROONDAS_CambiarEstado(MW_IDLE);
            }

            MICROONDAS_30Seconds();

            if (Estado_sistema == MW_IDLE)
            {
                MICROONDAS_EmpezarCoccion();
            }
            break;

        case 'D':
            Puerta_abierta = (Puerta_abierta == FALSE) ? TRUE : FALSE;

            if ((Puerta_abierta == TRUE) && (Estado_sistema == MW_COCINANDO))
            {
                MICROONDAS_CambiarEstado(MW_PAUSADO);
            }

            Pantalla_sucia = TRUE;
            break;

        default:
            break;
    }
}

//Tarea periodica de 1 segundo para descontar coccion y contar fin
static void MICROONDAS_OneSecondTask(void)
{
    if (Estado_sistema == MW_COCINANDO)
    {
        if (Tiempo_coccion_segundos > 0)
        {
            Tiempo_coccion_segundos--;
            MICROONDAS_LoadDigitsFromSeconds(Tiempo_coccion_segundos);
            Pantalla_sucia = TRUE;
        }

        if (Tiempo_coccion_segundos == 0)
        {
            Finalizado_segundos_transcurridos = 0;
            Parpadeo = TRUE;
            MICROONDAS_CambiarEstado(MW_TERMINADO);
        }
    }
    else if (Estado_sistema == MW_TERMINADO)
    {
        if (Finalizado_segundos_transcurridos < 5)
        {
            Finalizado_segundos_transcurridos++;
        }

        if (Finalizado_segundos_transcurridos >= 5)
        {
            MICROONDAS_LimpiarTiempo();
            MICROONDAS_CambiarEstado(MW_IDLE);
            Parpadeo = TRUE;
        }
    }
}

//Tarea periodica de 500 ms para parpadeo de fin de coccion
static void MICROONDAS_Parpadear(void)
{
    if (Estado_sistema == MW_TERMINADO)
    {
        Parpadeo = (Parpadeo == TRUE) ? FALSE : TRUE;
        Pantalla_sucia = TRUE;
    }
    else
    {
        Parpadeo = TRUE;
    }
}

//Cambia el estado de la MEF
static void MICROONDAS_CambiarEstado(micro_estados_t nuevo_estado)
{
    Estado_sistema = nuevo_estado;
    Contador_llamados_estado = 0;
    Pantalla_sucia = TRUE;
}

//Borra el tiempo ingresado y vuelve a 00:00
static void MICROONDAS_LimpiarTiempo(void)
{
    Tiempo_digitos[0] = 0;
    Tiempo_digitos[1] = 0;
    Tiempo_digitos[2] = 0;
    Tiempo_digitos[3] = 0;
    Tiempo_coccion_segundos = 0;
    Pantalla_sucia = TRUE;
}

//Ingresa un digito en formato MMSS por desplazamiento
static void MICROONDAS_InputDigit(uint8_t digit)
{
    uint8_t new_digits[4];
    uint8_t seconds_field;

    new_digits[0] = Tiempo_digitos[1];
    new_digits[1] = Tiempo_digitos[2];
    new_digits[2] = Tiempo_digitos[3];
    new_digits[3] = digit;

    seconds_field = (uint8_t)((new_digits[2] * 10) + new_digits[3]);

    if (seconds_field > 59)
    {
        MICROONDAS_Printear(MSG_INVALIDO);
        return;
    }

    Tiempo_digitos[0] = new_digits[0];
    Tiempo_digitos[1] = new_digits[1];
    Tiempo_digitos[2] = new_digits[2];
    Tiempo_digitos[3] = new_digits[3];

    Tiempo_coccion_segundos = MICROONDAS_DigitsToSeconds();
    Pantalla_sucia = TRUE;
}

//Convierte los cuatro digitos MMSS a segundos totales
static uint16_t MICROONDAS_DigitsToSeconds(void)
{
    uint16_t minutes;
    uint16_t seconds;

    minutes = (uint16_t)((Tiempo_digitos[0] * 10) + Tiempo_digitos[1]);
    seconds = (uint16_t)((Tiempo_digitos[2] * 10) + Tiempo_digitos[3]);

    return (uint16_t)((minutes * 60U) + seconds);
}

//Carga los digitos MMSS desde segundos totales
static void MICROONDAS_LoadDigitsFromSeconds(uint16_t total_seconds)
{
    uint8_t minutes;
    uint8_t seconds;

    if (total_seconds > MAX_TIEMPO_SEGUNDOS)
    {
        total_seconds = MAX_TIEMPO_SEGUNDOS;
    }

    minutes = (uint8_t)(total_seconds / 60U);
    seconds = (uint8_t)(total_seconds % 60U);

    Tiempo_digitos[0] = (uint8_t)(minutes / 10U);
    Tiempo_digitos[1] = (uint8_t)(minutes % 10U);
    Tiempo_digitos[2] = (uint8_t)(seconds / 10U);
    Tiempo_digitos[3] = (uint8_t)(seconds % 10U);
}

//Suma 30 segundos y satura en 99:59
static void MICROONDAS_30Seconds(void)
{
    if (Tiempo_coccion_segundos > (MAX_TIEMPO_SEGUNDOS - 30U))
    {
        Tiempo_coccion_segundos = MAX_TIEMPO_SEGUNDOS;
    }
    else
    {
        Tiempo_coccion_segundos = (uint16_t)(Tiempo_coccion_segundos + 30U);
    }

    MICROONDAS_LoadDigitsFromSeconds(Tiempo_coccion_segundos);
    Pantalla_sucia = TRUE;
}

//Intenta iniciar o reanudar la coccion
static void MICROONDAS_EmpezarCoccion(void)
{
    if (Puerta_abierta == TRUE)
    {
        MICROONDAS_Printear(MSG_PUERTA_ABIERTA);
        return;
    }

    if (Tiempo_coccion_segundos == 0)
    {
        MICROONDAS_Printear(MSG_TIEMPO_CERO);
        return;
    }

    MICROONDAS_CambiarEstado(MW_COCINANDO);
}

//Actualiza los LEDs de acuerdo con el estado actual
static void MICROONDAS_ActualizarLeds(void)
{
    if ((Estado_sistema == MW_COCINANDO) && (Puerta_abierta == FALSE))
    {
        PORTB |= (1 << LED_MAGNETRON_PIN);
    }
    else
    {
        PORTB &= ~(1 << LED_MAGNETRON_PIN);
    }

    if ((Estado_sistema == MW_COCINANDO) ||
        (Estado_sistema == MW_PAUSADO)  ||
        (Puerta_abierta == TRUE))
    {
        PORTC |= (1 << LED_INTERIOR_PIN);
    }
    else
    {
        PORTC &= ~(1 << LED_INTERIOR_PIN);
    }

    if ((Estado_sistema == MW_TERMINADO) && (Parpadeo == TRUE))
    {
        PORTC |= (1 << LED_ALARMA_PIN);
    }
    else
    {
        PORTC &= ~(1 << LED_ALARMA_PIN);
    }
}

//Actualiza las dos lineas del LCD
static void MICROONDAS_ActualizarDisplay(void)
{
    char line1[17];
    const char *line2;
    uint8_t minutes;
    uint8_t seconds;
    uint8_t i;

    if ((Estado_sistema == MW_TERMINADO) && (Parpadeo == FALSE))
    {
        LCD_WriteFixedLine(0, "                ");
        LCD_WriteFixedLine(1, "                ");
        return;
    }

    minutes = (uint8_t)(Tiempo_coccion_segundos / 60U);
    seconds = (uint8_t)(Tiempo_coccion_segundos % 60U);

    line1[0] = (char)('0' + (minutes / 10U));
    line1[1] = (char)('0' + (minutes % 10U));
    line1[2] = ':';
    line1[3] = (char)('0' + (seconds / 10U));
    line1[4] = (char)('0' + (seconds % 10U));

    for (i = 5; i < 16; i++)
    {
        line1[i] = ' ';
    }

    line1[16] = '\0';

    if (Message_ticks_100ms != 0)
    {
        if (Message_code == MSG_PUERTA_ABIERTA)
        {
            line2 = "PUERTA ABIERTA";
        }
        else if (Message_code == MSG_TIEMPO_CERO)
        {
            line2 = "TIEMPO 00:00";
        }
        else if (Message_code == MSG_INVALIDO)
        {
            line2 = "SEGUNDOS > 59";
        }
        else
        {
            line2 = "MENSAJE";
        }
    }
    else
    {
        switch (Estado_sistema)
        {
            case MW_IDLE:
                line2 = (Puerta_abierta == TRUE) ? "PUERTA ABIERTA" : "INGRESE TIEMPO";
                break;

            case MW_COCINANDO:
                line2 = "COCINANDO";
                break;

            case MW_PAUSADO:
                line2 = (Puerta_abierta == TRUE) ? "PAUSA PUERTA" : "PAUSADO";
                break;

            case MW_TERMINADO:
                line2 = "FIN COCCION";
                break;

            default:
                line2 = "ERROR ESTADO";
                break;
        }
    }

    LCD_WriteFixedLine(0, line1);
    LCD_WriteFixedLine(1, line2);
}

//Activa un mensaje temporal por 1 segundo en la segunda linea
static void MICROONDAS_Printear(uint8_t code)
{
    Message_code = code;
    Message_ticks_100ms = 10;
    Pantalla_sucia = TRUE;
}