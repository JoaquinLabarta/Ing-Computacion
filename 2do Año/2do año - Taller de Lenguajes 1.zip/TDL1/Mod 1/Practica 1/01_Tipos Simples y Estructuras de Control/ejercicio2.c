#include <stdio.h>
int main(){
    int nro;
scanf("%d", &nro);
switch nro % 2
{
case 0 : printf("Es par\n");
case 1 : printf("Es impar\n");
}
}