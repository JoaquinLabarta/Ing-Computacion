#include <stdio.h>
void verBits( unsigned );
int main()
{
  unsigned x;

  printf("Ingrese un entero sin signo: ");
  scanf("%u", &x);

  verBits(x);

  return 0;
}

void verBits(unsigned valor){


}

