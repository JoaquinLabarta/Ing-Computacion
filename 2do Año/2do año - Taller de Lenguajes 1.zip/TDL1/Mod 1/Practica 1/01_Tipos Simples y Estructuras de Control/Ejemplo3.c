#include <stdio.h>
int main()
{  float AVG;
   int suma, cant;

   suma = 232;
   cant = 10;

   AVG = (float) suma / cant;

   printf("Promedio = %5.2f", AVG);

   return 0;
}
